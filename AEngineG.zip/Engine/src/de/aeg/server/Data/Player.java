package de.aeg.server.Data;

import java.util.ArrayList;

import de.aeg.server.Server.Connection;

public class Player extends GameObject {

	private final Connection con;

	public Player(Connection con, int id) {
		super(id);

		this.con = con;
		con.write(this.getId() + "");
	}

	/**
	 * Receives newest data from client and sends updated data
	 * @param ArrayList of GameObjects that changed
	 */
	
	public void tick(ArrayList<GameObject> changes) {
		if (this.con.isConnected()) {
			
			// receives, sorts and updates data sent from client
			
			new Thread(() -> {
				String[] readarr = this.con.read().split(",");
				for (String read : readarr) {
					if (read != null) {
						String evnt = read.split(":")[0].toLowerCase();
						String data = read.split(":")[1].toLowerCase();
//				System.out.println(evnt + ":" + data);
						switch (evnt) {
						case "move":
							MoveState oldmove = this.getMove();
							switch (data) {
							case "w":
								this.setMove(MoveState.up);
								break;
							case "wd":
								this.setMove(MoveState.up_right);
								break;
							case "d":
								this.setMove(MoveState.right);
								break;
							case "sd":
								this.setMove(MoveState.down_right);
								break;
							case "s":
								this.setMove(MoveState.down);
								break;
							case "sa":
								this.setMove(MoveState.down_left);
								break;
							case "a":
								this.setMove(MoveState.left);
								break;
							case "wa":
								this.setMove(MoveState.up_left);
								break;
							default:
								this.setMove(MoveState.none);
								break;
							}
							if (oldmove != this.getMove()) {
								System.out.println(this.getMove().toString());
							}
							break;
						case "type":
							this.setType(Type.valueOf(data));
							break;
						}
					}
				}
			}).start();
			
			// builds and sends new data for every updated GameObject, acquired from the engine
			
			new Thread(() -> {
				for (GameObject obj : changes) {
					// id, pos(x;y), type, lastmove, hp
					StringBuilder pkg = new StringBuilder();
					pkg.append("id:");
					pkg.append(obj.getId());

					pkg.append(",");

					pkg.append("pos:");
					pkg.append(obj.getLoc().getX());
					pkg.append(";");
					pkg.append(obj.getLoc().getY());

					pkg.append(",");

					pkg.append("type:");
					pkg.append(obj.getType());

					pkg.append(",");

					pkg.append("move:");
					pkg.append(obj.getLastMove());

					pkg.append(",");

					pkg.append("hp:");
					pkg.append(obj.getHp());
					System.out.println(pkg.toString());

				}
			}).start();
		} else {
			this.setMove(MoveState.none);
		}
	}

}
