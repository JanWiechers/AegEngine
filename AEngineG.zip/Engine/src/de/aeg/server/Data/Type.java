package de.aeg.server.Data;

public enum Type {

	a,
	b,
	c,
	arrow_a,
	arrow_b,
	arrow_c,
	wall,
	none
	
}
