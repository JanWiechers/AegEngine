package de.aeg.server.Engine;
import de.aeg.server.Engine.MoveState;

public class Engine {
	GameObject[] Players;
	GameObject[] Walls;
	public Engine(GameObject[] Play, GameObject[] Block) {
		Players = Play;
		Walls = Block;
		System.out.println("Running");
		while (true){
			Tick();
		}
	}
	
	public void Tick() {
		for(GameObject p : Players) {
			int speed = p.get_Speed();
			int px = p.get_x();
			int py = p.get_y();
			int oy = py;
			int ox = px;
			MoveState m = p.get_Move();
			switch(m) {
			case up:
				py += speed;
				break;
			case up_left:
				py += speed;
				px -= speed;
				break;
			case up_right:
				py += speed;
				px += speed;
				break;
			case down:
				py -= speed;
				break;
			case down_left:
				py -= speed;
				px -= speed;
				break;
			case down_right:
				py -= speed;
				px -= speed;
				break;
			case left:
				px -= speed;
				break;
			case right:
				px += speed;
				break;
			case none:
				break;
			}
			p.set_x(px);
			p.set_y(py);
			boolean no_collide = true;
			for(GameObject w : Walls) {
				if(check_collision(p, w)) {
					no_collide = false;
					break;
				}
			}
			if(!no_collide) {
				System.out.print("Collision at: ");
				p.set_x(ox);
				p.set_y(oy);
			}
			p.print_data();
		}
		
	}
	public boolean check_collision(GameObject a, GameObject b) {
		int dx = a.get_x() - b.get_x();
		int dy = a.get_y() - b.get_y();
		double ds = (a.get_size() *0.5 + b.get_size() * 0.5);
		if(dx < ds && dy < ds) {
			return true;
		}
		else {
			return false;
		}
		
	}
}
