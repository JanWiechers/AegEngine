package de.aeg.server.Engine;
import de.aeg.server.Engine.MoveState;

public class Engine {
	GameObject[] Players;
	GameObject[] Walls;
	int Unit_Size;
	int Unit_Speed;
	public Engine(GameObject[] Play, GameObject[] Block, int Unit_Square, int Speed_Base) {
		Players = Play;
		Walls = Block;
		Unit_Size = Unit_Square;
		Unit_Speed = Speed_Base;
		System.out.println("Running");
		while (true){
			Tick();
		}
	}
	
	public void Tick() {
		for(GameObject p : Players) {
			int speed = Unit_Speed;
			int px = p.getLoc().getX();
			int py = p.getLoc().getY();
			int oy = py;
			int ox = px;
			MoveState m = p.getMove();
			switch(m) {
			case up:
				py += speed;
				break;
			case up_left:
				py += speed;
				px -= speed;
				break;
			case up_right:
				py += speed;
				px += speed;
				break;
			case down:
				py -= speed;
				break;
			case down_left:
				py -= speed;
				px -= speed;
				break;
			case down_right:
				py -= speed;
				px -= speed;
				break;
			case left:
				px -= speed;
				break;
			case right:
				px += speed;
				break;
			case none:
				break;
			}
			p.getLoc().setX(px);
			p.getLoc().setY(py);
			boolean no_collide = true;
			for(GameObject w : Walls) {
				if(check_collision(p, w)) {
					no_collide = false;
					break;
				}
			}
			for(GameObject o : Players) {
				if(check_collision(p, o) && p != o) {
					no_collide = false;
					break;
				}
			}
			if(!no_collide) {
				System.out.print("Collision at: ");
				p.getLoc().setX(ox);
				p.getLoc().setY(oy);
			}
		}
		
	}
	public boolean check_collision(GameObject a, GameObject b) {
		int dx = a.getLoc().getX() - b.getLoc().getX();
		int dy = a.getLoc().getY() - b.getLoc().getY();
		double ds = (Unit_Size *0.5 + Unit_Size * 0.5);
		if(dx < ds && dy < ds) {
			return true;
		}
		else {
			return false;
		}
		
	}
}
