package de.aeg.server.Engine;

public class GameObject {
	//physics
	int pos_x;
	int pos_y;
	int size;
	int speed;
	private MoveState ms = MoveState.down;
	
	public GameObject(int x, int y, int s,int sp) {
		pos_x = x;
		pos_y = y;
		size = s;
		speed = sp;
	}
	
	//Get Data
	public int get_x() {
		return pos_x;
	}
	public int get_y() {
		return pos_y;
	}
	public int get_size() {
		return size;
	}
	public int get_Speed() {
		return speed;
	}
	public MoveState get_Move() {
		return this.ms;
	}
	public void set_state() {
		ms = MoveState.none;
	}
	public void set_x(int x) {
		pos_x = x;
	}
	public void set_y(int y) {
		pos_y = y;
	}
	public void print_data() {
		System.out.print(pos_x);
		System.out.print(pos_y);
		System.out.println();
	}


}
