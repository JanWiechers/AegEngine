package de.aeg.server.Engine;

public class Main {
	public static void main(String[] args) {
		GameObject p1 = new GameObject(0);
		GameObject w1 = new GameObject(1);
		GameObject[] p = new GameObject[] {p1};
		GameObject[] w = new GameObject[] {w1};
		Engine e = new Engine(p,w);
	}
}
