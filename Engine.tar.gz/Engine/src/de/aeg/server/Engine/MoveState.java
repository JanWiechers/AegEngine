package de.aeg.server.Engine;

public enum MoveState {
	up,down,left,right,up_left,up_right,down_left,down_right,none
}
